#!/usr/bin/env python3
"""
build_corpus.py — turn the raw Trigedasleng dumps into one clean,
retrieval-ready corpus.jsonl.

Each output line is a "document": the text that gets embedded plus the
metadata that lets the chatbot cite and filter (canon status, source,
episode, gloss, etc.). Stdlib only — runs anywhere.

Usage:
    python build_corpus.py --uploads /path/to/uploads --out corpus.jsonl
"""
import argparse, json, re, hashlib, os, sys
from collections import Counter

# ---------------------------------------------------------------- helpers

def norm_status(raw):
    """Collapse the messy `filter` values into canon | noncanon | slakkru."""
    s = (raw or "").strip().lower()
    if not s:
        return "unknown"
    if "slakgedasleng" in s or "slakkru" in s:
        return "slakkru"
    if "noncanon" in s:
        return "noncanon"
    if "canon" in s:
        return "canon"
    return "unknown"

def split_pos(translation):
    """`"verb: to show humility, to abase"` -> ("verb", "to show humility, to abase")."""
    if ":" in translation[:25]:
        pos, rest = translation.split(":", 1)
        pos = pos.strip().lower()
        # only treat it as POS if it looks like one (a short word/phrase)
        if 0 < len(pos) <= 20 and " " not in pos.strip().rstrip(" noun"):
            return pos, rest.strip()
        if pos in {"proper noun", "auxiliary verb"}:
            return pos, rest.strip()
    return None, translation.strip()

def clean_etym(etym):
    e = (etym or "").strip()
    e = re.sub(r"^from:\s*", "", e, flags=re.I)
    return e.strip()

def dedupe_doubled(text):
    """`"foo bar foo bar"` -> `"foo bar"` (the doubled-note bug in the dump)."""
    t = (text or "").strip()
    if not t:
        return ""
    n = len(t)
    if n % 2 == 0:
        half = n // 2
        a, b = t[:half].strip(), t[half:].strip()
        if a and a == b:
            return a
    # also catch "X X" with a space between identical halves
    words = t.split()
    if len(words) % 2 == 0:
        half = len(words) // 2
        if words[:half] == words[half:]:
            return " ".join(words[:half])
    return t

def doc_id(prefix, *parts):
    h = hashlib.sha1("||".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:10]
    return f"{prefix}:{h}"

# ---------------------------------------------------------------- dictionary

def load_dictionary(paths):
    """Merge the dictionary dumps, dedupe distinct senses, normalize fields."""
    seen = {}                      # (word, pos, definition) -> record
    raw_count = 0
    for p in paths:
        if not os.path.exists(p):
            continue
        for r in json.load(open(p, encoding="utf-8")):
            raw_count += 1
            word = (r.get("word") or "").strip()
            if not word:
                continue
            pos, definition = split_pos(r.get("translation", ""))
            status = norm_status(r.get("filter"))
            note = dedupe_doubled(r.get("note", ""))
            etym = clean_etym(r.get("etymology", ""))
            example = (r.get("example") or "").strip()
            cit = (r.get("citations") or "").strip()
            key = (word.lower(), pos, definition.lower())
            rec = seen.get(key)
            if rec is None:
                seen[key] = {
                    "word": word, "pos": pos, "definition": definition,
                    "status": status, "etymology": etym, "note": note,
                    "example": example, "citations": cit,
                }
            else:
                # merge: prefer canon status, keep the longer note/example, union citations
                order = {"canon": 3, "noncanon": 2, "slakkru": 1, "unknown": 0}
                if order[status] > order[rec["status"]]:
                    rec["status"] = status
                if len(note) > len(rec["note"]):
                    rec["note"] = note
                if len(example) > len(rec["example"]):
                    rec["example"] = example
                if cit and cit not in rec["citations"]:
                    rec["citations"] = (rec["citations"] + " " + cit).strip()
    docs = []
    for rec in seen.values():
        parts = [rec["word"]]
        if rec["pos"]:
            parts.append(f"({rec['pos']})")
        parts.append(f"— {rec['definition']}")
        line = " ".join(parts)
        if rec["etymology"]:
            line += f". Etymology: {rec['etymology']}"
        if rec["example"]:
            line += f". Example: {rec['example']}"
        if rec["note"]:
            line += f". Note: {rec['note']}"
        line += f". [{rec['status']}]"
        docs.append({
            "doc_id": doc_id("dict", rec["word"], rec["pos"], rec["definition"]),
            "type": "dictionary",
            "text": line,
            "metadata": rec,
        })
    return docs, raw_count

# ---------------------------------------------------------------- translations

def load_translations(path):
    docs = []
    for r in json.load(open(path, encoding="utf-8")):
        trig = (r.get("trigedasleng") or "").strip()
        eng = (r.get("translation") or "").strip()
        if not trig or not eng:
            continue
        literal = (r.get("etymology") or "").strip()      # word-by-word English
        leipzig = (r.get("leipzig") or "").strip()        # interlinear gloss
        episode = (r.get("episode") or "").strip()
        text = f"Trigedasleng: {trig}\nEnglish: {eng}"
        if literal:
            text += f"\nLiteral: {literal}"
        if leipzig:
            text += f"\nGloss: {leipzig}"
        docs.append({
            "doc_id": doc_id("trans", trig, eng),
            "type": "translation",
            "text": text,
            "metadata": {
                "trigedasleng": trig, "english": eng,
                "literal": literal, "leipzig": leipzig,
                "episode": episode, "speaker": (r.get("speaker") or "").strip(),
                "audio": (r.get("audio") or "").strip(),
                "source": (r.get("source") or "").strip(),
                "status": "canon" if episode else "unknown",
            },
        })
    return docs

# ---------------------------------------------------------------- grammar

def load_grammar(path, target_words=180):
    """Heading-aware chunker for the grammar text, capped by length."""
    raw = open(path, encoding="utf-8").read().replace("\r\n", "\n")
    lines = raw.split("\n")
    heading_re = re.compile(r"^(\d+(\.\d+)*\.?\s+\S|[A-Z][A-Za-z ]{2,40}:)\s*$")
    sections, cur_head, buf = [], "Grammar", []
    def flush():
        if buf:
            sections.append((cur_head, "\n".join(buf).strip()))
    for ln in lines:
        if heading_re.match(ln.strip()) and ln.strip():
            flush(); buf = []; cur_head = ln.strip()
        else:
            buf.append(ln)
    flush()

    docs = []
    for head, body in sections:
        if not body.strip():
            continue
        words = body.split()
        # pack into chunks of ~target_words, each prefixed with its heading
        for i in range(0, len(words), target_words):
            chunk = " ".join(words[i:i + target_words])
            docs.append({
                "doc_id": doc_id("gram", head, i),
                "type": "grammar",
                "text": f"[{head}] {chunk}",
                "metadata": {"section": head, "status": "canon",
                             "source": "trigedasleng_v9.pdf (DJP reference grammar)"},
            })
    return docs

# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uploads", default="/mnt/user-data/uploads")
    ap.add_argument("--out", default="corpus.jsonl")
    args = ap.parse_args()

    u = args.uploads
    dict_docs, raw = load_dictionary(
        [os.path.join(u, "dictionary_canon.json"), os.path.join(u, "dictionary.json")])
    trans_docs = load_translations(os.path.join(u, "translations.json"))
    gram_docs = load_grammar(os.path.join(u, "grammar_rules.txt"))

    all_docs = dict_docs + trans_docs + gram_docs
    with open(args.out, "w", encoding="utf-8") as fh:
        for d in all_docs:
            fh.write(json.dumps(d, ensure_ascii=False) + "\n")

    print(f"raw dictionary rows read : {raw}")
    print(f"dictionary docs (deduped): {len(dict_docs)}")
    print(f"  by status: {Counter(d['metadata']['status'] for d in dict_docs)}")
    print(f"translation docs         : {len(trans_docs)}")
    print(f"  with leipzig gloss     : {sum(1 for d in trans_docs if d['metadata']['leipzig'])}")
    print(f"grammar chunks           : {len(gram_docs)}")
    print(f"TOTAL docs -> {args.out}: {len(all_docs)}")
    print("\n--- sample dictionary doc ---")
    print(json.dumps(dict_docs[0], ensure_ascii=False, indent=2))
    print("\n--- sample translation doc ---")
    print(json.dumps(trans_docs[0], ensure_ascii=False, indent=2))
    print("\n--- sample grammar doc ---")
    print(json.dumps(next(d for d in gram_docs if len(d["text"]) > 200), ensure_ascii=False, indent=2)[:900])

if __name__ == "__main__":
    main()
