# Trigedasleng RAG chatbot — starter pipeline

A grounded retrieval pipeline for translating and answering questions about
Trigedasleng, built on the dictionary, parallel-sentence, and grammar dumps.

## Files
- `build_corpus.py` — normalizes + merges the raw dumps into `corpus.jsonl`
  (one retrieval-ready document per line, with citation metadata).
- `corpus.jsonl` — the built corpus (3,862 docs: 2,691 dictionary senses,
  1,146 attested sentences, 25 grammar chunks).
- `rag.py` — embeds the corpus, retrieves type-aware cited context, calls the LLM.
- `system_prompt.txt` — the grounding prompt (no fabrication, status-aware, cited).

## Run it
```bash
# 1. build the corpus from your uploads
python build_corpus.py --uploads /path/to/uploads --out corpus.jsonl

# 2a. offline smoke test (no model, no network):
python rag.py --embedder stub --llm none "how do you say my fight is over"

# 2b. real semantic retrieval only (downloads a small embedding model once):
pip install sentence-transformers numpy
python rag.py --llm none "how do you say my fight is over"

# 3. full chatbot against a self-hosted model on your HPC (vLLM/TGI):
export OPENAI_BASE_URL=http://your-hpc-node:8000/v1
export OPENAI_MODEL=meta-llama/Llama-3.1-8B-Instruct
python rag.py --llm openai "translate: blood must have blood"

#    ...or against the Anthropic API:
export ANTHROPIC_API_KEY=...
python rag.py --llm anthropic --canon-only "what does 'gonplei' mean?"
```

## How it works
Retrieval pulls a **quota from each document type** (vocabulary + attested
sentences + grammar) rather than a flat top-k, so translations get grounded in
real examples, not just word lookups. The system prompt forces the model to cite
sources, flag canon vs noncanon vs slakkru, and refuse to invent words.

## Roadmap (in priority order)
1. **Hold out a test set** of ~100 translation pairs before tuning anything, so
   you can measure quality (e.g. chrF/BLEU for Trig output, plus spot-checks).
2. **Collapse duplicate sentences** spoken across multiple episodes into one doc
   with an episode list (small `build_corpus.py` change).
3. **Parse the full 178-page PDF grammar** into proper sections — the current
   `grammar_rules.txt` chunking is coarse and is the weakest retrieval source.
4. **Evaluate retrieval-only translation.** Only if it's not fluent enough:
   LoRA/QLoRA fine-tune on the 1,146 pairs (fits one GPU), optionally after
   synthetic augmentation using the grammar rules.
5. **Audio**: the 804 sentences with audio paths can power pronunciation playback
   or, later, a TTS layer — out of scope for the text bot.
