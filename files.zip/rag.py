#!/usr/bin/env python3
"""
rag.py — index the Trigedasleng corpus and answer questions with grounding.

Pipeline:
    1. embed every doc in corpus.jsonl (cached to disk)
    2. for a query, retrieve a quota from each doc type (dictionary / translation /
       grammar) so translations get both vocabulary AND example sentences
    3. build a cited context block and ask the LLM, with a system prompt that
       forbids fabricating words

Embedder backends:
    --embedder sentence-transformers   (default; great on your HPC, runs offline
                                        after the model is cached)
    --embedder stub                    (hash-based, no deps — for smoke-testing
                                        the retrieval logic without a model)

LLM backends:
    --llm openai     OpenAI-compatible endpoint (vLLM / TGI). Set OPENAI_BASE_URL
                     + OPENAI_API_KEY. This is the self-hosted path.
    --llm anthropic  Anthropic API. Set ANTHROPIC_API_KEY.
    --llm none       retrieval only; prints the context block (no model needed)
"""
import argparse, json, os, sys, hashlib
import numpy as np

SYSTEM_PROMPT = open(os.path.join(os.path.dirname(__file__), "system_prompt.txt"),
                     encoding="utf-8").read() if os.path.exists(
    os.path.join(os.path.dirname(__file__), "system_prompt.txt")) else ""

# ------------------------------------------------------------------ embedders

class STEmbedder:
    """Real semantic embeddings. Pick any sentence-transformers model; on HPC a
    larger one (e.g. BAAI/bge-large-en-v1.5) costs you nothing per query."""
    def __init__(self, model_name="BAAI/bge-small-en-v1.5"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
    def encode(self, texts):
        v = self.model.encode(texts, normalize_embeddings=True,
                              show_progress_bar=False, convert_to_numpy=True)
        return v.astype("float32")

class StubEmbedder:
    """Deterministic hashing embedder. No semantics — only for verifying that the
    indexing/retrieval plumbing runs end-to-end offline."""
    def __init__(self, dim=256):
        self.dim = dim
    def encode(self, texts):
        out = np.zeros((len(texts), self.dim), dtype="float32")
        for i, t in enumerate(texts):
            for tok in t.lower().split():
                h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
                out[i, h % self.dim] += 1.0
        n = np.linalg.norm(out, axis=1, keepdims=True)
        n[n == 0] = 1
        return out / n

def make_embedder(name):
    return StubEmbedder() if name == "stub" else STEmbedder()

# ------------------------------------------------------------------ index

class Index:
    def __init__(self, corpus_path, embedder, cache="embeddings.npy"):
        self.docs = [json.loads(l) for l in open(corpus_path, encoding="utf-8")]
        self.embedder = embedder
        self.cache = cache
        self.vecs = None
    def build(self, force=False):
        if not force and os.path.exists(self.cache):
            self.vecs = np.load(self.cache)
            if self.vecs.shape[0] == len(self.docs):
                return
        self.vecs = self.embedder.encode([d["text"] for d in self.docs])
        np.save(self.cache, self.vecs)
    def retrieve(self, query, quotas=None, status_filter=None):
        quotas = quotas or {"dictionary": 6, "translation": 6, "grammar": 3}
        q = self.embedder.encode([query])[0]
        sims = self.vecs @ q                       # cosine (vectors are normalized)
        order = np.argsort(-sims)
        picked, counts = [], {k: 0 for k in quotas}
        for idx in order:
            d = self.docs[idx]
            t = d["type"]
            if t not in counts or counts[t] >= quotas[t]:
                continue
            if status_filter and d["metadata"].get("status") not in status_filter:
                continue
            picked.append((float(sims[idx]), d))
            counts[t] += 1
            if all(counts[k] >= quotas[k] for k in quotas):
                break
        return picked

# ------------------------------------------------------------------ context

def format_context(hits):
    lines = []
    for score, d in hits:
        m = d["metadata"]
        tag = d["doc_id"]
        if d["type"] == "translation" and m.get("episode"):
            tag += f" | episode {m['episode']}"
        lines.append(f"[{tag} | {m.get('status','?')}]\n{d['text']}")
    return "\n\n".join(lines)

# ------------------------------------------------------------------ llm calls

def call_anthropic(system, user):
    import anthropic
    c = anthropic.Anthropic()
    r = c.messages.create(model="claude-sonnet-4-6", max_tokens=1024,
                          system=system, messages=[{"role": "user", "content": user}])
    return "".join(b.text for b in r.content if b.type == "text")

def call_openai(system, user):
    from openai import OpenAI
    c = OpenAI(base_url=os.environ.get("OPENAI_BASE_URL"))   # your vLLM endpoint
    r = c.chat.completions.create(
        model=os.environ.get("OPENAI_MODEL", "local-model"),
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": user}],
        max_tokens=1024, temperature=0.2)
    return r.choices[0].message.content

# ------------------------------------------------------------------ main

def answer(index, question, llm, status_filter=None):
    hits = index.retrieve(question, status_filter=status_filter)
    context = format_context(hits)
    user_msg = f"SOURCES:\n{context}\n\nQUESTION: {question}"
    if llm == "none":
        return f"--- retrieved context ---\n{context}"
    if llm == "anthropic":
        return call_anthropic(SYSTEM_PROMPT, user_msg)
    return call_openai(SYSTEM_PROMPT, user_msg)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="corpus.jsonl")
    ap.add_argument("--embedder", default="sentence-transformers",
                    choices=["sentence-transformers", "stub"])
    ap.add_argument("--llm", default="none", choices=["none", "anthropic", "openai"])
    ap.add_argument("--canon-only", action="store_true",
                    help="restrict retrieval to canon (screen-attested) material")
    ap.add_argument("--rebuild", action="store_true")
    ap.add_argument("question", nargs="*")
    args = ap.parse_args()

    idx = Index(args.corpus, make_embedder(args.embedder))
    idx.build(force=args.rebuild)
    sf = {"canon"} if args.canon_only else None

    if args.question:
        print(answer(idx, " ".join(args.question), args.llm, sf))
    else:
        print("Trigedasleng RAG ready. Type a question (Ctrl-D to quit).")
        for line in sys.stdin:
            line = line.strip()
            if line:
                print("\n" + answer(idx, line, args.llm, sf) + "\n")

if __name__ == "__main__":
    main()
